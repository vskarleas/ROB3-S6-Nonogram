To convert spaces to lines go to https://www.browserling.com/tools/spaces-to-newlines

We need this for columns sequences
